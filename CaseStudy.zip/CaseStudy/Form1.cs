﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;

namespace CaseStudy
{

    
    public partial class Form1 : MetroForm
    {

        adminLogin adminLogin = new adminLogin();
        memberForm2 memberForm = new memberForm2();
        public Form1()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void adminBtn_Click(object sender, EventArgs e)
        {
            adminLogin.Show();
            Visible = false;
        }

        private void MemberBtn_Click(object sender, EventArgs e)
        {
            memberForm.Show();
            Visible = false;
        }
    }
}
