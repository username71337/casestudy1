﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace CaseStudy
{
    public partial class adminLogin : MetroForm
    {
        string username = "admin";
        string password = "admin";
        StaffInfo staffInfo = new StaffInfo();
        public adminLogin()
        {
            InitializeComponent();
        }

        private void adminLogin_Load(object sender, EventArgs e)
        {
            
        }

        private void adminLoginBtn_Click(object sender, EventArgs e)
        {
            if (adminUsername.Text == username && adminPassword.Text == password)
            {
                MessageBox.Show("Login Successful", "Success");

                staffInfo.Show();
                Visible = false;

            }
            else
            {
                MessageBox.Show("Incorrect Username or Password", "Error");
            }
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Visible = false;

        }
    }
}
