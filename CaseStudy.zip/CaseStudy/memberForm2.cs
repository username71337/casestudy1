﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
using System.Data.SqlClient;

namespace CaseStudy
{
    public partial class memberForm2 : MetroForm
    {

        memberRegistration memberRegistration = new memberRegistration();
        memberForm1 memberLogin = new memberForm1();
        public memberForm2()
        {
            InitializeComponent();
        }

        private void memberRegisterBtn_Click(object sender, EventArgs e)
        {

            memberRegistration.Show();
            Visible = false;
            
        }

        private void memberLoginBtn_Click(object sender, EventArgs e)
        {
            memberLogin.Show();
            Visible = false;
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Visible = false;
        }
    }
}
