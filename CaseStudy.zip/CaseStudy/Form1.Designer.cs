﻿namespace CaseStudy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MemberBtn = new MetroFramework.Controls.MetroButton();
            this.adminBtn = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // MemberBtn
            // 
            this.MemberBtn.BackColor = System.Drawing.Color.White;
            this.MemberBtn.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.MemberBtn.Location = new System.Drawing.Point(544, 265);
            this.MemberBtn.Name = "MemberBtn";
            this.MemberBtn.Size = new System.Drawing.Size(159, 54);
            this.MemberBtn.TabIndex = 0;
            this.MemberBtn.TabStop = false;
            this.MemberBtn.Text = " Member";
            this.MemberBtn.UseSelectable = true;
            this.MemberBtn.Click += new System.EventHandler(this.MemberBtn_Click);
            // 
            // adminBtn
            // 
            this.adminBtn.BackColor = System.Drawing.Color.White;
            this.adminBtn.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.adminBtn.Location = new System.Drawing.Point(319, 265);
            this.adminBtn.Name = "adminBtn";
            this.adminBtn.Size = new System.Drawing.Size(159, 54);
            this.adminBtn.TabIndex = 0;
            this.adminBtn.TabStop = false;
            this.adminBtn.Text = "admin";
            this.adminBtn.UseSelectable = true;
            this.adminBtn.Click += new System.EventHandler(this.adminBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1007, 556);
            this.Controls.Add(this.adminBtn);
            this.Controls.Add(this.MemberBtn);
            this.Name = "Form1";
            this.Text = "Homepage";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton MemberBtn;
        private MetroFramework.Controls.MetroButton adminBtn;
    }
}

