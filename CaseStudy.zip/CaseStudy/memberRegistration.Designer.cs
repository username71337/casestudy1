﻿namespace CaseStudy
{
    partial class memberRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registerBtn = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.memberNameTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.memberUsernameTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.memberPasswordTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.membershipTypeTxt = new System.Windows.Forms.ComboBox();
            this.backBtn = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // registerBtn
            // 
            this.registerBtn.Location = new System.Drawing.Point(447, 382);
            this.registerBtn.Name = "registerBtn";
            this.registerBtn.Size = new System.Drawing.Size(75, 23);
            this.registerBtn.TabIndex = 0;
            this.registerBtn.TabStop = false;
            this.registerBtn.Text = "Register";
            this.registerBtn.UseSelectable = true;
            this.registerBtn.Click += new System.EventHandler(this.registerBtn_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(311, 143);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(50, 20);
            this.metroLabel1.TabIndex = 1;
            this.metroLabel1.Text = "Name:";
            // 
            // memberNameTxt
            // 
            // 
            // 
            // 
            this.memberNameTxt.CustomButton.Image = null;
            this.memberNameTxt.CustomButton.Location = new System.Drawing.Point(187, 1);
            this.memberNameTxt.CustomButton.Name = "";
            this.memberNameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.memberNameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.memberNameTxt.CustomButton.TabIndex = 1;
            this.memberNameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.memberNameTxt.CustomButton.UseSelectable = true;
            this.memberNameTxt.CustomButton.Visible = false;
            this.memberNameTxt.Lines = new string[0];
            this.memberNameTxt.Location = new System.Drawing.Point(386, 140);
            this.memberNameTxt.MaxLength = 32767;
            this.memberNameTxt.Name = "memberNameTxt";
            this.memberNameTxt.PasswordChar = '\0';
            this.memberNameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.memberNameTxt.SelectedText = "";
            this.memberNameTxt.SelectionLength = 0;
            this.memberNameTxt.SelectionStart = 0;
            this.memberNameTxt.ShortcutsEnabled = true;
            this.memberNameTxt.Size = new System.Drawing.Size(209, 23);
            this.memberNameTxt.TabIndex = 2;
            this.memberNameTxt.UseSelectable = true;
            this.memberNameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.memberNameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(237, 196);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(124, 20);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Membership Type:";
            // 
            // memberUsernameTxt
            // 
            // 
            // 
            // 
            this.memberUsernameTxt.CustomButton.Image = null;
            this.memberUsernameTxt.CustomButton.Location = new System.Drawing.Point(187, 1);
            this.memberUsernameTxt.CustomButton.Name = "";
            this.memberUsernameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.memberUsernameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.memberUsernameTxt.CustomButton.TabIndex = 1;
            this.memberUsernameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.memberUsernameTxt.CustomButton.UseSelectable = true;
            this.memberUsernameTxt.CustomButton.Visible = false;
            this.memberUsernameTxt.Lines = new string[0];
            this.memberUsernameTxt.Location = new System.Drawing.Point(386, 246);
            this.memberUsernameTxt.MaxLength = 32767;
            this.memberUsernameTxt.Name = "memberUsernameTxt";
            this.memberUsernameTxt.PasswordChar = '\0';
            this.memberUsernameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.memberUsernameTxt.SelectedText = "";
            this.memberUsernameTxt.SelectionLength = 0;
            this.memberUsernameTxt.SelectionStart = 0;
            this.memberUsernameTxt.ShortcutsEnabled = true;
            this.memberUsernameTxt.Size = new System.Drawing.Size(209, 23);
            this.memberUsernameTxt.TabIndex = 6;
            this.memberUsernameTxt.UseSelectable = true;
            this.memberUsernameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.memberUsernameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(285, 249);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(76, 20);
            this.metroLabel3.TabIndex = 5;
            this.metroLabel3.Text = "Username:";
            // 
            // memberPasswordTxt
            // 
            // 
            // 
            // 
            this.memberPasswordTxt.CustomButton.Image = null;
            this.memberPasswordTxt.CustomButton.Location = new System.Drawing.Point(187, 1);
            this.memberPasswordTxt.CustomButton.Name = "";
            this.memberPasswordTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.memberPasswordTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.memberPasswordTxt.CustomButton.TabIndex = 1;
            this.memberPasswordTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.memberPasswordTxt.CustomButton.UseSelectable = true;
            this.memberPasswordTxt.CustomButton.Visible = false;
            this.memberPasswordTxt.Lines = new string[0];
            this.memberPasswordTxt.Location = new System.Drawing.Point(386, 294);
            this.memberPasswordTxt.MaxLength = 32767;
            this.memberPasswordTxt.Name = "memberPasswordTxt";
            this.memberPasswordTxt.PasswordChar = '\0';
            this.memberPasswordTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.memberPasswordTxt.SelectedText = "";
            this.memberPasswordTxt.SelectionLength = 0;
            this.memberPasswordTxt.SelectionStart = 0;
            this.memberPasswordTxt.ShortcutsEnabled = true;
            this.memberPasswordTxt.Size = new System.Drawing.Size(209, 23);
            this.memberPasswordTxt.TabIndex = 8;
            this.memberPasswordTxt.UseSelectable = true;
            this.memberPasswordTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.memberPasswordTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(292, 294);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(69, 20);
            this.metroLabel4.TabIndex = 7;
            this.metroLabel4.Text = "Password:";
            // 
            // membershipTypeTxt
            // 
            this.membershipTypeTxt.FormattingEnabled = true;
            this.membershipTypeTxt.Items.AddRange(new object[] {
            "1",
            "2"});
            this.membershipTypeTxt.Location = new System.Drawing.Point(387, 196);
            this.membershipTypeTxt.Name = "membershipTypeTxt";
            this.membershipTypeTxt.Size = new System.Drawing.Size(208, 24);
            this.membershipTypeTxt.TabIndex = 9;
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(447, 433);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 10;
            this.backBtn.Text = "Back";
            this.backBtn.UseSelectable = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // memberRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 539);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.membershipTypeTxt);
            this.Controls.Add(this.memberPasswordTxt);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.memberUsernameTxt);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.memberNameTxt);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.registerBtn);
            this.Name = "memberRegistration";
            this.Text = "Member Registration";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.memberRegistration_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton registerBtn;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox memberNameTxt;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox memberUsernameTxt;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox memberPasswordTxt;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.ComboBox membershipTypeTxt;
        private MetroFramework.Controls.MetroButton backBtn;
    }
}