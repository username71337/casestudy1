﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MetroFramework.Forms;
using System.Reflection;
using System.Runtime.InteropServices.ComTypes;

namespace CaseStudy
{
    public partial class memberPage : MetroForm
    {

        SqlConnection con = new SqlConnection(@"Data source = RETARDLUL\SQLEXPRESS; Initial Catalog = CaseStudyDB; integrated security = true;");
        SqlDataReader rdr;
        SqlCommand cmd;

        int memberID;
        public memberPage()
        {
            InitializeComponent();
            memberUsernameTxt.Text = memberForm1.username;
            memberPasswordTxtBox.Text = memberForm1.password;
            
        }

        private void SetConnection()
        {
            con = new SqlConnection(@"Data source = RETARDLUL\SQLEXPRESS; Initial Catalog = CaseStudyDB; integrated security = true;");
        }
        private void LoadActivity()
        {
            memberActivityGrid.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT * FROM ACTIVITIES;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                memberActivityGrid.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString(), rdr[4].ToString(), rdr[5].ToString(), rdr[6].ToString(), rdr[7].ToString());

            }
            con.Close();
        }

        string username;

        private void memberPage_Load(object sender, EventArgs e)
        {
            SetConnection();
            LoadMemberDetails();
            LoadActivity();
            LoadFinancialHistory();
            LoadPreference();
  
        }

        private void LoadMemberDetails()
        {
            con.Open();
            cmd = new SqlCommand(@"SELECT * FROM MEMBERS WHERE memberUsername = '"+memberUsernameTxt.Text+"';", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                memberIDLabel.Text = memberIDLabel.Text + rdr[0].ToString();
                memberID = Convert.ToInt32(rdr[0]);
                dateJoinedLabel.Text = dateJoinedLabel.Text + rdr[2].ToString();
                membershipTypeLabel.Text = membershipTypeLabel.Text + rdr[4].ToString();
                memberNameTxtBox.Text = rdr[1].ToString();
                memberPasswordTxtBox.Text = rdr[5].ToString();
            }
            con.Close();
        }

       
        private void LoadFinancialHistory()
        {
            memberFinancialHistory.Rows.Clear();
            activityTrackingGrid.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT * FROM TRANSACTIONS WHERE transactionMember = '"+memberNameTxtBox.Text+"';", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                memberFinancialHistory.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[4].ToString(), rdr[3].ToString(), rdr[5].ToString(), rdr[6].ToString());

                activityTrackingGrid.Rows.Add(rdr[0].ToString(), rdr[3].ToString(), rdr[7].ToString());

            }
            con.Close();
        }

        private void transactionBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand(@"INSERT INTO TRANSACTIONS(transactionDate, transactionAmount, transactionActivity, activityID, transactionMember, memberID, transactionStatus) VALUES('" + DateTime.Now.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss") + "', '" + activityFeeTxt.Text + "', '" + activityNameTxt.Text + "', '" + activityIDTxtBox.Text + "', '" + memberNameTxtBox.Text + "', '"+memberID+"', 'Ongoing');", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Success");
            LoadFinancialHistory();
            LoadPreference();
        }

        private void memberActivityGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (memberActivityGrid.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = memberActivityGrid.SelectedRows[0];
                activityIDTxtBox.Text = selectedRow.Cells[0].Value.ToString();
                activityNameTxt.Text = selectedRow.Cells[1].Value.ToString();
                activityFeeTxt.Text = selectedRow.Cells[4].Value.ToString();
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            if (activityTrackingGrid.SelectedRows.Count > 0)
            {
                con.Open();
                cmd = new SqlCommand(@"UPDATE TRANSACTIONS
                    SET transactionStatus = 'Cancelled' WHERE transactionID = '"+IDtxtBox1.Text+"'", con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Activity details updated", "Success");
                LoadFinancialHistory();
            }
        }

        private void activityTrackingGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (activityTrackingGrid.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = activityTrackingGrid.SelectedRows[0];
                IDtxtBox1.Text = selectedRow.Cells[0].Value.ToString();
            }
        }

        private void detailsUpdateBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand(@"UPDATE MEMBERS SET memberName = '" + memberNameTxtBox.Text + "', memberPassword = '" + memberPasswordTxtBox.Text + "' WHERE memberID = '" + memberID + "';", con);
            cmd.ExecuteNonQuery();
            con.Close();


            con.Open();
            cmd = new SqlCommand(@"UPDATE TRANSACTIONS SET transactionMember = '" + memberNameTxtBox.Text + "' WHERE memberID = '" + memberID + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Member Details Updated", "Success");
            LoadFinancialHistory();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            memberForm1 memberform1 = new memberForm1();
            memberform1.Show();
            Visible = false;
        }

        private void LoadPreference()
        {
            preferenceGrid.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT transactionActivity, count(transactionActivity) as occurences from TRANSACTIONS WHERE transactionMember = '"+memberNameTxtBox.Text+"' group by transactionActivity order by occurences desc;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                preferenceGrid.Rows.Add(rdr[0].ToString(), rdr[1].ToString());
                preferenceTxt.Text = preferenceGrid.Rows[0].Cells[0].Value.ToString();
            }
            con.Close();
            
        }

        private void preferenceBtn_Click(object sender, EventArgs e)
        {
            if (preferenceGrid.Rows.Count > 0)
            {
                con.Open();
                cmd = new SqlCommand(@"UPDATE MEMBERS SET memberPreferences = '" + preferenceTxt.Text + "' WHERE memberName = '" + memberNameTxtBox.Text + "';", con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Preference Updated", "Success");
                LoadPreference();
            }
        }
    }
}
